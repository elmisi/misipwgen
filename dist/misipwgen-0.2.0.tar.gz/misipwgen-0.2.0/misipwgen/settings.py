SYLLABLES_FILE = "misipwgen/it_syllables.csv"
